-- Single-slot Admin setup script for Supabase Dashboard -> SQL Editor
-- Project: ngkftevfykpndkcnoicr
-- Preserves existing admin #1 and bookings, removes any second slot.

create table if not exists public.appointment_bookings (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  phone text not null,
  service_id text not null,
  service_title text,
  package_id text,
  package_tier text,
  currency text default 'INR',
  preferred_date date not null,
  preferred_time text not null,
  birth_date text,
  birth_time text,
  birth_location text,
  message text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);

-- Ensure all expected columns exist if the table was created earlier (non-destructive)
alter table public.appointment_bookings add column if not exists service_title text;
alter table public.appointment_bookings add column if not exists package_id text;
alter table public.appointment_bookings add column if not exists package_tier text;
alter table public.appointment_bookings add column if not exists currency text default 'INR';
alter table public.appointment_bookings add column if not exists birth_date text;
alter table public.appointment_bookings add column if not exists birth_time text;
alter table public.appointment_bookings add column if not exists birth_location text;
alter table public.appointment_bookings add column if not exists message text;
alter table public.appointment_bookings add column if not exists status text not null default 'pending';
alter table public.appointment_bookings add column if not exists created_at timestamptz not null default now();

-- Single-slot Admin table: enforces at most ONE admin account in the entire database (id = 1)
create table if not exists public.admin_users (
  id integer primary key default 1 check (id = 1),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  email text not null,
  created_at timestamptz not null default now()
);

-- Clean up any second slot if it was previously inserted (keeps admin #1)
delete from public.admin_users where id <> 1;

-- Safely update constraint back to id = 1
do $$
declare
  c record;
begin
  for c in
    select conname
    from pg_constraint
    where conrelid = 'public.admin_users'::regclass
      and contype = 'c'
  loop
    execute format('alter table public.admin_users drop constraint if exists %I', c.conname);
  end loop;
end
$$;

alter table public.admin_users alter column id set default 1;
alter table public.admin_users add constraint admin_users_id_check check (id = 1);

-- Enable Row Level Security (idempotent)
alter table public.appointment_bookings enable row level security;
alter table public.admin_users enable row level security;

-- Explicit least-privilege table permissions
grant usage on schema public to anon, authenticated;
grant insert on public.appointment_bookings to anon, authenticated;
grant select, update, delete on public.appointment_bookings to authenticated;
grant select, insert on public.admin_users to authenticated;

-- Helper function callable by the frontend to check if the single admin slot is already claimed
create or replace function public.is_admin_registered()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (select 1 from public.admin_users);
$$;

grant execute on function public.is_admin_registered() to anon, authenticated;

-- Booking form inserts: public visitors can submit appointments
drop policy if exists "Allow public appointment booking inserts" on public.appointment_bookings;
create policy "Allow public appointment booking inserts"
  on public.appointment_bookings
  for insert
  to anon, authenticated
  with check (true);

-- Booking reads/updates/deletes: ONLY the single registered admin can view or manage bookings
drop policy if exists "Admin can view all bookings" on public.appointment_bookings;
create policy "Admin can view all bookings"
  on public.appointment_bookings
  for select
  to authenticated
  using (
    exists (
      select 1 from public.admin_users where user_id = auth.uid()
    )
  );

drop policy if exists "Admin can update bookings" on public.appointment_bookings;
create policy "Admin can update bookings"
  on public.appointment_bookings
  for update
  to authenticated
  using (
    exists (
      select 1 from public.admin_users where user_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.admin_users where user_id = auth.uid()
    )
  );

drop policy if exists "Admin can delete bookings" on public.appointment_bookings;
create policy "Admin can delete bookings"
  on public.appointment_bookings
  for delete
  to authenticated
  using (
    exists (
      select 1 from public.admin_users where user_id = auth.uid()
    )
  );

-- Admin slot policies:
-- 1. Only the logged-in admin can read their own row
drop policy if exists "Admin can view own admin record" on public.admin_users;
create policy "Admin can view own admin record"
  on public.admin_users
  for select
  to authenticated
  using (auth.uid() = user_id);

-- 2. Only allow claiming the single slot (id = 1) if NO admin exists yet
drop policy if exists "Allow claiming up to two admin slots" on public.admin_users;
drop policy if exists "Allow claiming single admin slot once" on public.admin_users;
create policy "Allow claiming single admin slot once"
  on public.admin_users
  for insert
  to authenticated
  with check (
    id = 1
    and auth.uid() = user_id
    and not exists (select 1 from public.admin_users)
  );
